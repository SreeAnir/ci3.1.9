<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
 ERROR - 2019-01-01 16:29:08 --> 404 Page Not Found: Assets/images
ERROR - 2019-01-01 16:29:21 --> 404 Page Not Found: Assets/images
ERROR - 2019-01-01 16:30:11 --> 404 Page Not Found: Assets1/images
ERROR - 2019-01-01 16:30:51 --> 404 Page Not Found: Assets/images
ERROR - 2019-01-01 16:39:29 --> Severity: error --> Exception: Required "app_id" key not supplied in config and could not find fallback environment variable "FACEBOOK_APP_ID" C:\wamp\www\c3\application\libraries\facebook-php-sdk\Facebook.php 139
ERROR - 2019-01-01 17:09:47 --> 404 Page Not Found: User_athentication/index
